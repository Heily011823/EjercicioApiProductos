<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class AndRoleToUserTable extends Migration
{


    public function up()
    {
        Schema::table('users', function (Blueprint $table) {
            $table->string('role',20)->default('usuario')->after('email');
        });
    }

    public function down()
    {
        Schema::table('users', function (Blueprint $table) {
            $table->dropColumn('role');
        });
    }
}
